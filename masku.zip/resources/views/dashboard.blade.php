@extends('layouts.base')

@section('content')
    <div class="bg-white p-6 rounded-xl shadow">
        <h2 class="text-xl font-semibold mb-2">Selamat datang di MASKU</h2>
        <p class="text-gray-600">Ini adalah halaman utama untuk mencatat transaksi emas.</p>
    </div>
@endsection
