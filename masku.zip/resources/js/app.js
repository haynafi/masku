import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();

import { createIcons, icons } from 'lucide';
createIcons({ icons });
